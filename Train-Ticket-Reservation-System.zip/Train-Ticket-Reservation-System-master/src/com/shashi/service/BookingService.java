// Package declaration indicating the location of the interface
package com.shashi.service;

// Importing necessary Java classes and custom classes
import java.util.List;
import com.shashi.beans.HistoryBean;
import com.shashi.beans.TrainException;

// Definition of the BookingService interface
public interface BookingService {

    /**
     * Retrieves all booking history records for a specific customer based on their email ID.
     *
     * @param customerEmailId The email ID of the customer for whom booking history is requested.
     * @return A list of HistoryBean objects representing booking history records.
     * @throws TrainException If an error occurs during the retrieval process.
     */
    public List<HistoryBean> getAllBookingsByCustomerId(String customerEmailId) throws TrainException;

    /**
     * Creates a new booking history record based on the provided HistoryBean.
     *
     * @param bookingDetails The HistoryBean object containing details of the booking to be created.
     * @return A HistoryBean object representing the newly created booking history record.
     * @throws TrainException If an error occurs during the creation process.
     */
    public HistoryBean createHistory(HistoryBean bookingDetails) throws TrainException;
}
