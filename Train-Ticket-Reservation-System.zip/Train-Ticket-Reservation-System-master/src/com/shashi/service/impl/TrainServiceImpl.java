// Package declaration indicating the location of the class
package com.shashi.service.impl;

// Importing necessary Java classes and custom classes
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shashi.beans.TrainBean;
import com.shashi.beans.TrainException;
import com.shashi.constant.ResponseCode;
import com.shashi.service.TrainService;
import com.shashi.utility.DBUtil;

// Service Implementation class for train operations
public class TrainServiceImpl implements TrainService {

    // Adds a new train to the system
    @Override
    public String addTrain(TrainBean train) {
        String responseCode = ResponseCode.FAILURE.toString();
        String query = "INSERT INTO TRAIN VALUES(?,?,?,?,?,?)";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            // Setting parameters for the prepared statement
            ps.setLong(1, train.getTr_no());
            ps.setString(2, train.getTr_name());
            ps.setString(3, train.getFrom_stn());
            ps.setString(4, train.getTo_stn());
            ps.setLong(5, train.getSeats());
            ps.setDouble(6, train.getFare());
            // Executing the update query and obtaining the result set
            ResultSet rs = ps.executeQuery();
            // Checking if the update was successful
            if (rs.next()) {
                responseCode = ResponseCode.SUCCESS.toString();
            }
            // Closing the prepared statement
            ps.close();
        } catch (SQLException | TrainException e) {
            // Handling SQL exceptions and custom TrainException
            responseCode += " : " + e.getMessage();
        }
        // Returning the response code
        return responseCode;
    }

    // Deletes a train from the system based on its train number
    @Override
    public String deleteTrainById(String trainNo) {
        String responseCode = ResponseCode.FAILURE.toString();
        String query = "DELETE FROM TRAIN WHERE TR_NO=?";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            // Setting parameters for the prepared statement
            ps.setString(1, trainNo);
            // Executing the update query and obtaining the response
            int response = ps.executeUpdate();
            // Checking if the update was successful
            if (response > 0) {
                responseCode = ResponseCode.SUCCESS.toString();
            }
            // Closing the prepared statement
            ps.close();
        } catch (SQLException | TrainException e) {
            // Handling SQL exceptions and custom TrainException
            responseCode += " : " + e.getMessage();
        }
        // Returning the response code
        return responseCode;
    }

    // Updates the details of an existing train in the system
    @Override
    public String updateTrain(TrainBean train) {
        String responseCode = ResponseCode.FAILURE.toString();
        String query = "UPDATE TRAIN SET TR_NAME=?, FROM_STN=?,TO_STN=?,SEATS=?,FARE=? WHERE TR_NO=?";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            // Setting parameters for the prepared statement
            ps.setString(1, train.getTr_name());
            ps.setString(2, train.getFrom_stn());
            ps.setString(3, train.getTo_stn());
            ps.setLong(4, train.getSeats());
            ps.setDouble(5, train.getFare());
            ps.setDouble(6, train.getTr_no());
            // Executing the update query and obtaining the result set
            ResultSet rs = ps.executeQuery();
            // Checking if the update was successful
            if (rs.next()) {
                responseCode = ResponseCode.SUCCESS.toString();
            }
            // Closing the prepared statement
            ps.close();
        } catch (SQLException | TrainException e) {
            // Handling SQL exceptions and custom TrainException
            responseCode += " : " + e.getMessage();
        }
        // Returning the response code
        return responseCode;
    }

    // Retrieves the details of a train based on its train number
    @Override
    public TrainBean getTrainById(String trainNo) throws TrainException {
        TrainBean train = null;
        String query = "SELECT * FROM TRAIN WHERE TR_NO=?";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            // Setting parameters for the prepared statement
            ps.setString(1, trainNo);
            // Executing the query and obtaining the result set
            ResultSet rs = ps.executeQuery();
            // Checking if the result set has data
            if (rs.next()) {
                // If data is present, creating a new TrainBean and setting its attributes
                train = new TrainBean();
                train.setFare(rs.getDouble("fare"));
                train.setFrom_stn(rs.getString("from_stn"));
                train.setTo_stn(rs.getString("to_stn"));
                train.setTr_name(rs.getString("tr_name"));
                train.setTr_no(rs.getLong("tr_no"));
                train.setSeats(rs.getInt("seats"));
            }
            // Closing the prepared statement
            ps.close
