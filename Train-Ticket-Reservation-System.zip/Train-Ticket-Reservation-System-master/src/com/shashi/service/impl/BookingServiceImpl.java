// Package declaration indicating the location of the class
package com.shashi.service.impl;

// Importing necessary Java classes and custom classes
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.shashi.beans.HistoryBean;
import com.shashi.beans.TrainException;
import com.shashi.constant.ResponseCode;
import com.shashi.service.BookingService;
import com.shashi.utility.DBUtil;

// Service Implementation class for booking details of the ticket
// Creates the booking history and saves it to the database
public class BookingServiceImpl implements BookingService {

    // Retrieves all booking history records for a specific customer based on their email ID
    @Override
    public List<HistoryBean> getAllBookingsByCustomerId(String customerEmailId) throws TrainException {
        List<HistoryBean> transactions = null;
        String query = "SELECT * FROM HISTORY WHERE MAILID=?";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, customerEmailId);
            // Executing the query and obtaining the result set
            ResultSet rs = ps.executeQuery();
            transactions = new ArrayList<HistoryBean>();
            // Processing the result set and populating the list of transactions
            while (rs.next()) {
                HistoryBean transaction = new HistoryBean();
                transaction.setTransId(rs.getString("transid"));
                transaction.setFrom_stn(rs.getString("from_stn"));
                transaction.setTo_stn(rs.getString("to_stn"));
                transaction.setDate(rs.getString("date"));
                transaction.setMailId(rs.getString("mailid"));
                transaction.setSeats(rs.getInt("seats"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTr_no(rs.getString("tr_no"));
                transactions.add(transaction);
            }
            // Closing the prepared statement
            ps.close();
        } catch (SQLException e) {
            // Handling SQL exceptions and throwing a custom TrainException
            System.out.println(e.getMessage());
            throw new TrainException(e.getMessage());
        }
        // Returning the list of transactions
        return transactions;
    }

    // Creates a new booking history record based on the provided HistoryBean
    @Override
    public HistoryBean createHistory(HistoryBean details) throws TrainException {
        HistoryBean history = null;
        String query = "INSERT INTO HISTORY VALUES(?,?,?,?,?,?,?,?)";
        try {
            // Establishing a database connection
            Connection con = DBUtil.getConnection();
            // Creating a prepared statement for executing SQL queries
            PreparedStatement ps = con.prepareStatement(query);
            // Generating a unique transaction ID using UUID
            String transactionId = UUID.randomUUID().toString();
            // Setting parameters for the prepared statement
            ps.setString(1, transactionId);
            ps.setString(2, details.getMailId());
            ps.setString(3, details.getTr_no());
            ps.setString(4, details.getDate());
            ps.setString(5, details.getFrom_stn());
            ps.setString(6, details.getTo_stn());
            ps.setLong(7, details.getSeats());
            ps.setDouble(8, details.getAmount());
            // Executing the update query and obtaining the response
            int response = ps.executeUpdate();
            // Checking if the update was successful
            if (response > 0) {
                // If successful, creating a new HistoryBean and setting its attributes
                history = new HistoryBean();
                history.setTransId(transactionId);
                history.setMailId(details.getMailId());
                history.setTr_no(details.getTr_no());
                history.setDate(details.getDate());
                history.setFrom_stn(details.getFrom_stn());
                history.setTo_stn(details.getTo_stn());
                history.setSeats(details.getSeats());
                history.setAmount(details.getAmount());
            } else {
                // If the update was not successful, throwing a TrainException with an internal server error
                throw new TrainException(ResponseCode.INTERNAL_SERVER_ERROR);
            }
            // Closing the prepared statement
            ps.close();
        } catch (SQLException e) {
            // Handling SQL exceptions and throwing a custom TrainException
            System.out.println(e.getMessage());
            throw new TrainException(e.getMessage());
        }
        // Returning the created history object
        return history;
    }
}
