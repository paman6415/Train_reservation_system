// Package declaration indicating the location of the interface
package com.shashi.service;

// Importing necessary Java classes and custom classes
import java.util.List;
import com.shashi.beans.TrainBean;
import com.shashi.beans.TrainException;

// Definition of the TrainService interface
public interface TrainService {

    /**
     * Adds a new train to the system.
     *
     * @param train The TrainBean object representing the details of the train to be added.
     * @return A string indicating the result of the operation.
     */
    public String addTrain(TrainBean train);

    /**
     * Deletes a train from the system based on its train number.
     *
     * @param trainNo The train number of the train to be deleted.
     * @return A string indicating the result of the operation.
     */
    public String deleteTrainById(String trainNo);

    /**
     * Updates the details of an existing train in the system.
     *
     * @param train The TrainBean object representing the updated details of the train.
     * @return A string indicating the result of the operation.
     */
    public String updateTrain(TrainBean train);

    /**
     * Retrieves the details of a train based on its train number.
     *
     * @param trainNo The train number of the train to be retrieved.
     * @return The TrainBean object representing the details of the retrieved train.
     * @throws TrainException If an error occurs during the retrieval process.
     */
    public TrainBean getTrainById(String trainNo) throws TrainException;

    /**
     * Retrieves details of all trains in the system.
     *
     * @return A list of TrainBean objects representing the details of all trains.
     * @throws TrainException If an error occurs during the retrieval process.
     */
    public List<TrainBean> getAllTrains() throws TrainException;

    /**
     * Retrieves details of trains that operate between two specified stations.
     *
     * @param fromStation The departure station.
     * @param toStation   The destination station.
     * @return A list of TrainBean objects representing the details of trains between the specified stations.
     * @throws TrainException If an error occurs during the retrieval process.
     */
    public List<TrainBean> getTrainsBetweenStations(String fromStation, String toStation) throws TrainException;
}
