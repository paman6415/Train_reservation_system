// Package declaration indicating the location of the servlet class
package com.shashi.servlets;

// Importing necessary Java classes and annotations
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shashi.constant.UserRole;
import com.shashi.utility.TrainUtil;

// Servlet annotation indicating the URL pattern for the servlet
@SuppressWarnings("serial")
@WebServlet("/addtrainfwd")
public class AddTrainFwd extends HttpServlet {

    /**
     * Handles the HTTP GET request.
     *
     * @param req The HttpServletRequest object representing the client's request
     * @param res The HttpServletResponse object representing the servlet's response
     * @throws IOException      If an I/O error occurs
     * @throws ServletException If a servlet-specific error occurs
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        // Setting the content type of the response
        res.setContentType("text/html");
        
        // Validating user authorization based on the user role
        TrainUtil.validateUserAuthorization(req, UserRole.ADMIN);
        
        // Obtaining a request dispatcher for forwarding the request to the "AddTrains.html" page
        RequestDispatcher rd = req.getRequestDispatcher("AddTrains.html");
        
        // Forwarding the request and response objects to the specified page
        rd.forward(req, res);
    }

}
