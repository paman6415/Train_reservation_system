// Package declaration indicating the location of the class
package com.shashi.constant;

// Importing necessary Java utility classes
import java.util.Arrays;
import java.util.Optional;

// Definition of the ResponseCode enum
public enum ResponseCode {

    // Enum constants representing different HTTP response codes and messages
    SUCCESS(200, "OK"),
    FAILURE(422, "Unprocessable Entity, Failed to Process"),
    NO_CONTENT(204, "No Items Found"),
    PAGE_NOT_FOUND(404, "The Page You are Searching For is Not Available"),
    ACCESS_DENIED(403, "Please Login First to Continue"),
    BAD_REQUEST(400, "Bad Request, Please Try Again"),
    UNAUTHORIZED(401,"Invalid Credentials, Try Again"),
    SESSION_EXPIRED(401, "Session Expired, Login Again to Continue"),
    INTERNAL_SERVER_ERROR(500, "Internal Server Error, Try Again!!"),
    DATABASE_CONNECTION_FAILURE(406,
            "Unable to Connect to DB, Please Check Your DB Credentials in application.properties"),
    METHOD_NOT_ALLOWED(405, "Requested HTTP Method is Not Supported by This URL"),

    // Private fields for storing associated message and code for each enum constant
    private final String message;
    private final int code;

    // Constructor for each enum constant
    ResponseCode(int code, String message) {
        this.message = message;
        this.code = code;
    }

    // Getter method for retrieving the message associated with the enum constant
    public String getMessage() {
        return message;
    }

    // Getter method for retrieving the code associated with the enum constant
    public int getCode() {
        return code;
    }

    // Reverse lookup method to find an enum constant by its code
    public static Optional<ResponseCode> getMessageByStatusCode(int statusCode) {
        return Arrays.stream(ResponseCode.values())
                .filter(error -> error.getCode() == statusCode)
                .findFirst();
    }
}
