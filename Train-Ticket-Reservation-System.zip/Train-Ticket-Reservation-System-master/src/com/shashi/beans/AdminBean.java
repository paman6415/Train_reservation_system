// Package declaration indicating the location of the class
package com.shashi.beans;

// Importing the Serializable interface
import java.io.Serializable;

// Definition of the AdminBean class, implementing the Serializable interface
public class AdminBean implements Serializable {
    // Unique identifier for serialization
    private static final long serialVersionUID = 1L;

    // Properties of the AdminBean class
    private String fName;   // First name
    private String lName;   // Last name
    private String pWord;   // Password
    private String addR;    // Address
    private String mailId;  // Email ID
    private long phNo;      // Phone number

    // Setter method for setting the password
    public void setPWord(String pWord) {
        this.pWord = pWord;
    }

    // Getter method for retrieving the password
    public String getPWord() {
        return pWord;
    }

    // Setter method for setting the first name
    public void setFName(String fName) {
        this.fName = fName;
    }

    // Getter method for retrieving the first name
    public String getFName() {
        return fName;
    }

    // Setter method for setting the last name
    public void setLName(String lName) {
        this.lName = lName;
    }

    // Getter method for retrieving the last name
    public String getLName() {
        return lName;
    }

    // Setter method for setting the address
    public void setAddr(String addR) {
        this.addR = addR;
    }

    // Getter method for retrieving the address
    public String getAddr() {
        return addR;
    }

    // Setter method for setting the email ID
    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    // Getter method for retrieving the email ID
    public String getMailId() {
        return mailId;
    }

    // Setter method for setting the phone number
    public void setPhNo(long phNo) {
        this.phNo = phNo;
    }

    // Getter method for retrieving the phone number
    public long getPhNo() {
        return phNo;
    }
}
